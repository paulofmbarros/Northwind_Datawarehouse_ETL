-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema dw_northwind
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema dw_northwind
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `dw_northwind` DEFAULT CHARACTER SET utf8 ;
USE `dw_northwind` ;

-- -----------------------------------------------------
-- Table `dw_northwind`.`dim_customers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`dim_customers` (
  `iddim_customers` INT NOT NULL AUTO_INCREMENT,
  `company` VARCHAR(50) NULL,
  `name` VARCHAR(100) NULL,
  `jobtitle` VARCHAR(50) NULL,
  `city` VARCHAR(50) NULL,
  `country` VARCHAR(50) NULL,
  `is_current` VARCHAR(3) NULL,
  `created_date` DATE NULL,
  `expired_date` DATE NULL,
  PRIMARY KEY (`iddim_customers`),
  UNIQUE INDEX `iddim_customers_UNIQUE` (`iddim_customers` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`dim_employees`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`dim_employees` (
  `iddim_employees` INT NOT NULL AUTO_INCREMENT,
  `company` VARCHAR(50) NULL,
  `name` VARCHAR(100) NULL,
  `jobtitle` VARCHAR(50) NULL,
  `city` VARCHAR(50) NULL,
  `country` VARCHAR(50) NULL,
  `is_current` VARCHAR(3) NULL,
  `created_date` DATE NULL,
  `expired_date` DATE NULL,
  PRIMARY KEY (`iddim_employees`),
  UNIQUE INDEX `iddim_employees_UNIQUE` (`iddim_employees` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`dim_shippers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`dim_shippers` (
  `iddim_shippers` INT NOT NULL AUTO_INCREMENT,
  `company` VARCHAR(50) NULL,
  `city` VARCHAR(50) NULL,
  `country` VARCHAR(50) NULL,
  `is_current` VARCHAR(3) NULL,
  `created_date` DATE NULL,
  `expired_date` DATE NULL,
  PRIMARY KEY (`iddim_shippers`),
  UNIQUE INDEX `iddim_shippers_UNIQUE` (`iddim_shippers` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`dim_data`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`dim_data` (
  `iddim_data` INT NOT NULL AUTO_INCREMENT,
  `Date_da_ordem` DATE NULL,
  `day_ordem` INT NULL,
  `year_ordem` INT NULL,
  `month` INT NULL,
  `day_of_week` VARCHAR(45) NULL,
  `week_of_year` INT NULL,
  `dia_util_ordem` VARCHAR(4) NULL,
  `feriado_ordem` VARCHAR(4) NULL,
  PRIMARY KEY (`iddim_data`),
  UNIQUE INDEX `iddim_data_UNIQUE` (`iddim_data` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`Dim_payment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`Dim_payment` (
  `idDim_payment` INT NOT NULL AUTO_INCREMENT,
  `payment_type` VARCHAR(50) NULL,
  PRIMARY KEY (`idDim_payment`),
  UNIQUE INDEX `idDim_payment_UNIQUE` (`idDim_payment` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`dim_order_status`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`dim_order_status` (
  `iddim_order_satus` INT NOT NULL,
  `status_name` VARCHAR(50) NULL,
  PRIMARY KEY (`iddim_order_satus`),
  UNIQUE INDEX `idOrder_satus_UNIQUE` (`iddim_order_satus` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`factos_order`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`factos_order` (
  `idfactos_order` INT NOT NULL,
  `dim_customers_iddim_customers` INT NOT NULL,
  `dim_employees_iddim_employees` INT NOT NULL,
  `dim_shippers_iddim_shippers` INT NULL,
  `dim_data_idorder_date` INT NOT NULL,
  `Dim_payment_idDim_payment` INT NULL,
  `dim_order_status_iddim_order_satus` INT NOT NULL,
  `dim_data_idpaid_date` INT NULL,
  `dim_data_idshipped_date` INT NULL,
  PRIMARY KEY (`idfactos_order`),
  UNIQUE INDEX `idfactos_order_UNIQUE` (`idfactos_order` ASC) VISIBLE,
  INDEX `fk_factos_order_dim_customers1_idx` (`dim_customers_iddim_customers` ASC) VISIBLE,
  INDEX `fk_factos_order_dim_employees1_idx` (`dim_employees_iddim_employees` ASC) VISIBLE,
  INDEX `fk_factos_order_dim_shippers1_idx` (`dim_shippers_iddim_shippers` ASC) VISIBLE,
  INDEX `fk_factos_order_dim_data1_idx` (`dim_data_idorder_date` ASC) VISIBLE,
  INDEX `fk_factos_order_Dim_payment1_idx` (`Dim_payment_idDim_payment` ASC) VISIBLE,
  INDEX `fk_factos_order_dim_order_status1_idx` (`dim_order_status_iddim_order_satus` ASC) VISIBLE,
  INDEX `fk_factos_order_dim_data2_idx` (`dim_data_idpaid_date` ASC) VISIBLE,
  INDEX `fk_factos_order_dim_data3_idx` (`dim_data_idshipped_date` ASC) VISIBLE,
  CONSTRAINT `fk_factos_order_dim_customers1`
    FOREIGN KEY (`dim_customers_iddim_customers`)
    REFERENCES `dw_northwind`.`dim_customers` (`iddim_customers`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_factos_order_dim_employees1`
    FOREIGN KEY (`dim_employees_iddim_employees`)
    REFERENCES `dw_northwind`.`dim_employees` (`iddim_employees`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_factos_order_dim_shippers1`
    FOREIGN KEY (`dim_shippers_iddim_shippers`)
    REFERENCES `dw_northwind`.`dim_shippers` (`iddim_shippers`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_factos_order_dim_data1`
    FOREIGN KEY (`dim_data_idorder_date`)
    REFERENCES `dw_northwind`.`dim_data` (`iddim_data`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_factos_order_Dim_payment1`
    FOREIGN KEY (`Dim_payment_idDim_payment`)
    REFERENCES `dw_northwind`.`Dim_payment` (`idDim_payment`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_factos_order_dim_order_status1`
    FOREIGN KEY (`dim_order_status_iddim_order_satus`)
    REFERENCES `dw_northwind`.`dim_order_status` (`iddim_order_satus`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_factos_order_dim_data2`
    FOREIGN KEY (`dim_data_idpaid_date`)
    REFERENCES `dw_northwind`.`dim_data` (`iddim_data`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_factos_order_dim_data3`
    FOREIGN KEY (`dim_data_idshipped_date`)
    REFERENCES `dw_northwind`.`dim_data` (`iddim_data`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`dim_suplier`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`dim_suplier` (
  `iddim_suplier` INT NOT NULL AUTO_INCREMENT,
  `company` VARCHAR(50) NULL,
  `name` VARCHAR(100) NULL,
  `jobtitle` VARCHAR(100) NULL,
  `is_current` VARCHAR(3) NULL,
  `created_date` DATE NULL,
  `expired_date` DATE NULL,
  PRIMARY KEY (`iddim_suplier`),
  UNIQUE INDEX `iddim_suplier_UNIQUE` (`iddim_suplier` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`dim_products`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`dim_products` (
  `iddim_products` INT NOT NULL,
  `name` VARCHAR(50) NULL,
  `standard_cost` DECIMAL(19,4) NULL,
  `list_price` DECIMAL(19,4) NULL,
  `category` VARCHAR(50) NULL,
  `quantity_stock` INT NULL,
  `is_current` VARCHAR(3) NULL,
  `created_date` DATE NULL,
  `expired_date` DATE NULL,
  PRIMARY KEY (`iddim_products`),
  UNIQUE INDEX `iddim_products_UNIQUE` (`iddim_products` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`dim_purchase_order`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`dim_purchase_order` (
  `iddim_purchase_order` INT NOT NULL,
  `status` VARCHAR(50) NULL,
  `dim_employees_iddim_employees` INT NULL,
  `dim_suplier_iddim_suplier` INT NOT NULL,
  `is_current` VARCHAR(3) NULL,
  `created_date` DATE NULL,
  `expired_date` DATE NULL,
  PRIMARY KEY (`iddim_purchase_order`),
  UNIQUE INDEX `iddim_purchase_order_UNIQUE` (`iddim_purchase_order` ASC) VISIBLE,
  INDEX `fk_dim_purchase_order_dim_employees1_idx` (`dim_employees_iddim_employees` ASC) VISIBLE,
  INDEX `fk_dim_purchase_order_dim_suplier1_idx` (`dim_suplier_iddim_suplier` ASC) VISIBLE,
  CONSTRAINT `fk_dim_purchase_order_dim_employees1`
    FOREIGN KEY (`dim_employees_iddim_employees`)
    REFERENCES `dw_northwind`.`dim_employees` (`iddim_employees`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_dim_purchase_order_dim_suplier1`
    FOREIGN KEY (`dim_suplier_iddim_suplier`)
    REFERENCES `dw_northwind`.`dim_suplier` (`iddim_suplier`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`dim_invoice`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`dim_invoice` (
  `iddim_invoice` INT NOT NULL,
  `factos_order_idfactos_order` INT NOT NULL,
  `is_current` VARCHAR(3) NULL,
  `created_date` DATE NULL,
  `expired_date` DATE NULL,
  PRIMARY KEY (`iddim_invoice`),
  UNIQUE INDEX `iddim_invoice_UNIQUE` (`iddim_invoice` ASC) VISIBLE,
  INDEX `fk_dim_invoice_factos_order1_idx` (`factos_order_idfactos_order` ASC) VISIBLE,
  CONSTRAINT `fk_dim_invoice_factos_order1`
    FOREIGN KEY (`factos_order_idfactos_order`)
    REFERENCES `dw_northwind`.`factos_order` (`idfactos_order`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`order_details_produto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`order_details_produto` (
  `order_details` INT NOT NULL,
  `factos_order_idfactos_order` INT NOT NULL,
  `dim_products_iddim_products` INT NOT NULL,
  `quantity` DECIMAL(18,4) NULL,
  `unit_price` DECIMAL(18,4) NULL,
  `is_current` VARCHAR(3) NULL,
  `created_date` DATE NULL,
  `expired_date` DATE NULL,
  INDEX `fk_table1_factos_order1_idx` (`factos_order_idfactos_order` ASC) VISIBLE,
  INDEX `fk_table1_dim_products1_idx` (`dim_products_iddim_products` ASC) VISIBLE,
  PRIMARY KEY (`order_details`),
  UNIQUE INDEX `order_detailsl_UNIQUE` (`order_details` ASC) VISIBLE,
  CONSTRAINT `fk_table1_factos_order1`
    FOREIGN KEY (`factos_order_idfactos_order`)
    REFERENCES `dw_northwind`.`factos_order` (`idfactos_order`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_table1_dim_products1`
    FOREIGN KEY (`dim_products_iddim_products`)
    REFERENCES `dw_northwind`.`dim_products` (`iddim_products`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`Dim_purchase_details`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`Dim_purchase_details` (
  `idpurchase_details` INT NOT NULL,
  `porduct_id` INT(11) NULL,
  `quantity` DECIMAL(18,14) NULL,
  `unit_cost` DECIMAL(18,14) NULL,
  `dim_purchase_order_iddim_purchase_order` INT NOT NULL,
  `is_current` VARCHAR(3) NULL,
  `created_date` DATE NULL,
  `expired_date` DATE NULL,
  PRIMARY KEY (`idpurchase_details`),
  UNIQUE INDEX `idpurchase_details_UNIQUE` (`idpurchase_details` ASC) VISIBLE,
  INDEX `fk_purchase_details_dim_purchase_order1_idx` (`dim_purchase_order_iddim_purchase_order` ASC) VISIBLE,
  CONSTRAINT `fk_purchase_details_dim_purchase_order1`
    FOREIGN KEY (`dim_purchase_order_iddim_purchase_order`)
    REFERENCES `dw_northwind`.`dim_purchase_order` (`iddim_purchase_order`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
