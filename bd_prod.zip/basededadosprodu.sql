-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema dw_northwind
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema dw_northwind
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `dw_northwind` DEFAULT CHARACTER SET utf8 ;
USE `dw_northwind` ;

-- -----------------------------------------------------
-- Table `dw_northwind`.`cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`cliente` (
  `idcliente` INT NULL,
  `first_name` VARCHAR(100) NULL,
  `last_name` VARCHAR(100) NULL,
  `company` VARCHAR(50) NULL,
  `jobtitle` VARCHAR(100) NULL,
  `city` VARCHAR(50) NULL,
  `country` VARCHAR(50) NULL,
  `type` VARCHAR(1) NOT NULL,
  `create_time` DATETIME NOT NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`faturas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`faturas` (
  `type` VARCHAR(1) NOT NULL,
  `create_time` DATETIME NOT NULL,
  `id_order` INT NULL,
  `id_fatura` INT NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`ordem`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`ordem` (
  `id_ordem` INT NULL,
  `id_empregado` INT NULL,
  `id_cliente` INT NULL,
  `data_ordem` DATE NULL,
  `data_paid` DATE NULL,
  `data_shipped` DATE NULL,
  `status_id` INT NULL,
  `id_remetente` INT NULL,
  `payment_type` VARCHAR(45) NULL,
  `type` VARCHAR(1) NOT NULL,
  `create_time` DATETIME NOT NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`compra_ordem`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`compra_ordem` (
  `id_compra_ordem` INT NULL,
  `status` INT NULL,
  `id_empregado` INT NULL,
  `id_fornecedor` INT NULL,
  `type` VARCHAR(1) NOT NULL,
  `create_time` DATETIME NOT NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`compra_ordem_detalhes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`compra_ordem_detalhes` (
  `id_compra_details` INT NULL,
  `product_id` INT NULL,
  `quantidade` DECIMAL(18,4) NULL,
  `unit_cost` DECIMAL(18,4) NULL,
  `compra_id` VARCHAR(45) NULL,
  `type` VARCHAR(1) NOT NULL,
  `create_time` DATETIME NOT NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`remetente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`remetente` (
  `id_remetente` INT NULL,
  `first_name` VARCHAR(100) NULL,
  `last_name` VARCHAR(100) NULL,
  `company` VARCHAR(50) NULL,
  `city` VARCHAR(50) NULL,
  `country` VARCHAR(50) NULL,
  `type` VARCHAR(1) NOT NULL,
  `create_time` DATETIME NOT NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`empregados`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`empregados` (
  `idempregados` INT NULL,
  `first_name` VARCHAR(100) NULL,
  `last_name` VARCHAR(100) NULL,
  `company` VARCHAR(50) NULL,
  `jobtitle` VARCHAR(100) NULL,
  `city` VARCHAR(50) NULL,
  `country` VARCHAR(50) NULL,
  `type` VARCHAR(1) NOT NULL,
  `create_time` DATETIME NOT NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`fornecedores`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`fornecedores` (
  `id_fornecedor` INT NULL,
  `first_name` VARCHAR(100) NULL,
  `last_name` VARCHAR(100) NULL,
  `company` VARCHAR(50) NULL,
  `jobtitle` VARCHAR(100) NULL,
  `type` VARCHAR(1) NOT NULL,
  `create_time` DATETIME NOT NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`produtos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`produtos` (
  `id_produto` INT NULL,
  `nome` VARCHAR(50) NULL,
  `quantidade` INT(11) NULL,
  `standard_cost` DECIMAL(19,4) NULL,
  `list_price` DECIMAL(19,4) NULL,
  `category` VARCHAR(50) NULL,
  `type` VARCHAR(1) NOT NULL,
  `create_time` DATETIME NOT NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dw_northwind`.`detalhes_ordem`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dw_northwind`.`detalhes_ordem` (
  `id_ordem_detalhes` INT NULL,
  `idprodutos` INT NULL,
  `id_factos` INT NULL,
  `quantidade` DECIMAL(18,4) NULL,
  `unit_price` DECIMAL(18,4) NULL,
  `type` VARCHAR(1) NOT NULL,
  `create_time` DATETIME NOT NULL)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
